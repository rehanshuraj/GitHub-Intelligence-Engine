An AI-powered chat application that lets you talk naturally with your friends while also interacting with an integrated AI agent. The AI bot can join conversations, answer questions, provide suggestions, or assist in discussions—making group chats smarter and more engaging.

✨ Features

 Friend-to-Friend Chat – Real-time chatting with your contacts.

 AI Agent Integration – Invite an AI bot into any conversation.

 Seamless AI Assistance – Ask the AI for facts, summaries, or fun interactions directly in the chat.

 AI in Between Conversations – The AI can step in when you need help, without disrupting your ongoing discussion.

 Smart Suggestions – AI provides tips, reminders, and context-aware responses.

 Use Cases

Chat casually with friends and let the AI join in for games, jokes, or trivia.

Get quick answers without leaving the conversation.

Use the AI as a personal assistant inside group discussions.

🛠️ Tech Stack

Frontend: React / Next.js

Backend: Node.js / Express

AI: Integrated with Gemini / OpenAI APIs

Database: MongoDB / PostgreSQL
 
 
